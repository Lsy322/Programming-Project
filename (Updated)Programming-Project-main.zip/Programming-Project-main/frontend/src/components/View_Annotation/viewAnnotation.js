import React from "react";
import { withStyles } from "@material-ui/core/styles";
import Dialog from "@material-ui/core/Dialog";
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogContent from "@material-ui/core/DialogContent";
import DialogActions from "@material-ui/core/DialogActions";
import IconButton from "@material-ui/core/IconButton";
import CloseIcon from "@material-ui/icons/Close";
import Typography from "@material-ui/core/Typography";

import ViewAnnotation from './Annotation_View';

const ViewAnnotationDialog = ({ open, setOpen, post }) => {
  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>View annotation</DialogTitle>
        <DialogContent>
          <ViewAnnotation post={post}/>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ViewAnnotationDialog;
